const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const path = require('path');
const fs = require('fs');
const http = require('http');

const app = express();
const PORT = 3000;

const API_URL = 'https://detmir.ara.mdaudit.dev';

// 👉 создаём http server (ВАЖНО для ws)
const server = http.createServer(app);

// =======================
// Главная страница
// =======================
app.get('/', (req, res) => {
  const token = req.query.token;

  if (!token) {
    return res.status(400).send('Missing token parameter');
  }

  const indexPath = path.join(__dirname, 'mobile-embed', 'index.html');
  let html = fs.readFileSync(indexPath, 'utf8');

  const script = `
    <script>
      localStorage.setItem('x-auth-token', '${token}');
    </script>
  `;

  html = html.replace('<head>', '<head>' + script);
  res.send(html);
});

// =======================
// Статика
// =======================
app.use(express.static(path.join(__dirname, 'mobile-embed'), { index: false }));

// =======================
// Proxy (HTTP + WS)
// =======================
const proxy = createProxyMiddleware({
  target: API_URL,
  changeOrigin: true,
  ws: true,
  secure: false, // полезно для dev / self-signed
  logLevel: 'warn',

  filter: (pathname) => {
    return !pathname.match(/\.(js|css|html|svg|png|jpg|woff|ttf|map|txt)$/);
  },

  onProxyReq: (proxyReq, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get('token');

    if (token) {
      proxyReq.setHeader('x-auth-token', token);
    }

    proxyReq.setHeader('x-device-uid', '8e5604af-99db-47a5-b5e9-465040486690');
    proxyReq.setHeader('x-device-platform', 'web');
  },

  // 🔥 важно для ws
  onProxyReqWs: (proxyReq, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get('token');

    if (token) {
      proxyReq.setHeader('x-auth-token', token);
    }

    proxyReq.setHeader('x-device-uid', '8e5604af-99db-47a5-b5e9-465040486690');
    proxyReq.setHeader('x-device-platform', 'web');
  }
});

// HTTP
app.use('/', proxy);

// WS (upgrade)
server.on('upgrade', proxy.upgrade);

// =======================
server.listen(PORT, '0.0.0.0', () => {
  console.log(`Server: http://localhost:${PORT}/`);
});
